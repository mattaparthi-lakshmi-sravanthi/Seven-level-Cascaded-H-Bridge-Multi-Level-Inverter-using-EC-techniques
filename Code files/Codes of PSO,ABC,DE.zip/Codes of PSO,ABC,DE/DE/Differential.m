clc                         % To clear the command window
clear                       % To clear the workspace
tic
%% Problem settings
lb = [0 0 0]                    % Lower bound
ub = [90 90 90]                % Upper bound
prob = @ObjFunSHE               % Fitness function


%% Parametewrs for Differential Evolution
Np = 100                   % Population Size
T = 200                    % No. of iterations
Pc =0.8                    % Crossover probability
F = 0.85                   % Scaling factor


%% Starting of DE
f = NaN(Np,1)  % Vector to store the fitness function value of the Np population

fu = NaN(Np,1) % Vector to store the fitness function value of newly generated trail vector

D = length(lb) % Determining the number of decision variable

U = NaN(Np,D)   % Matrix to store trail solution

randpop = repmat(lb,Np,1 ) + repmat ((ub-lb),Np,1).* rand(Np,D)
trans1 = randpop.'
trans2 = sort(trans1)
P = trans2.'  


for p = 1:Np
    a=P(p,:)
    f(p) = prob(a) 
end

%% Iteration loop
for t = 1:T
    
    for i = 1:Np
        
        %% Mutation
        Candidates = [1:i-1 i+1:Np]
        idx = Candidates(randperm(Np-1,3))
        
        X1 = P(idx(1),:)
        X2 = P(idx(2),:)
        X3 = P(idx(3),:)
        
        V = X1 +F*(X2-X3)
        
        
        %% Crossover
        
        del = randi(D,1)
        for j = 1:D
            
            if (rand <= Pc) || del == j
                U(i,j)= V(j)
            else
                U(i,j) = P(i,j)
            end
            
        end
    end
    
    %% Bounding and Greedy selection
    for j = 1:Np
        
        U(j,:) = min (ub,U(j,:))
        U(j,:) = max (lb,U(j,:))
        
        fu(j) = prob(U(j,:))
        
        if fu(j) < f(j)
            P(j,:) = U(j,:)
            f(j) = fu(j)
        end
    end
    
    
end

[bestfitness, ind] =  min(f)
bestsol = P(ind,:)
bestsol = sort(bestsol);
a1 = (bestsol(1))
a2 = (bestsol(2))
a3 = (bestsol(3))

MI = (cosd(a1)+cosd(a2)+cosd(a3))/3
Vdc=85.15


toc




            
            
                
            
        


