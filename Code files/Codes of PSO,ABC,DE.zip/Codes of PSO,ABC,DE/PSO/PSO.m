clc                           % To clear the command window
lb = [0 0 0]                  % Lower bound
ub = [90 90 90]               % Upper bound
tic
prob = @ObjFunSHE             % Fitness function

%% Algorithm parameters
Np = 100                      % Population Size
T = 200                       % No. of iterations
w = 0.8                       % Interia weight
acc1 = 1.5                    % Acceleration coefficient
acc2 = 1.5                    % Acceleration coefficient


%% Particle Swarm Optimization
f = NaN(Np,1)                 % Vector to store the fitness function value of the population

D = length(lb)                % Determining the number of decision variable in the problem

randpop = repmat(lb,Np,1) + repmat((ub-lb),Np,1).*rand(Np,D) % Generation of the initial population
trans1 = randpop.'
trans2 = sort(trans1)
P = trans2.'                                           %% Sorted population

v = repmat(lb,Np,1) + repmat((ub-lb),Np,1).*rand(Np,D) % Generation of intial velocity

for p = 1:Np
    a=P(p,:)
    f(p) = prob(a)                                      % Evaluating the fitness function of the intial population
end

pbest = P                                                % Initialize the personal best solution 
f_pbest = f;                                             % Intialize the fitness of the personal best solutions


[f_gbest,ind] = min(f_pbest)          % Determining the best objective fitness function value
gbest = P(ind,:)                      % Determining the best solution

for t = 1:T
    
    for p = 1:Np
        
        v(p,:) = w*v(p,:) + acc1*rand(1,D).*(pbest(p,:)-P(p,:)) + acc2*rand(1,D).*(gbest - P(p,:)) % Determine the new velocity
        
        P(p,:) = P(p,:) + v(p,:)    % Update the position
        
        P(p,:) = max(P(p,:),lb)    % Bounding the violating variables to their lower bound
        P(p,:) = min(P(p,:),ub)     % Bounding the violating variables to their upper bound
        
          a = P(p,:)
        f(p)  = prob(a)       % Determining the fitness of the new solution
        
        if f(p) < f_pbest(p)
            
            f_pbest(p) = f(p)      % updating the fitness function value of the personal best
            pbest(p,:) = P(p,:)     % updating the personal best solution
            
            if f_pbest(p) < f_gbest
                
                f_gbest = f_pbest(p) % updating the fitness function value of the best solution
                gbest = pbest(p,:)   % updating the best solution
                
            end
            
        end
        gbestitr(t) = f_gbest;
    end
end

bestfitness = f_gbest
bestsol = gbest
bestsol = sort(bestsol);
a1 = (bestsol(1));
a2 = (bestsol(2));
a3 = (bestsol(3));

Vdc = 85.15
MI = (cosd(a1)+cosd(a2)+cosd(a3))/3


toc