

for j=-10:0.001:10
    cdf=0
    for i=1:100
        if(total(i,5)<=(10^(j)))
            cdf=cdf+1;
 
        end
    end
    plot((10^(j)),cdf,'*')
    hold on
end