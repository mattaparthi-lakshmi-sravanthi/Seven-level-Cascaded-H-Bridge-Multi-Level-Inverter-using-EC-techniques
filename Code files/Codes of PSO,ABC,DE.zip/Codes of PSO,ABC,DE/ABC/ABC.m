clc
clear
tic
%% Problem Settings
lb = [0 0 0]                 % Lower bound
ub = [90 90 90]             % Upper bound
prob = @ObjFunSHE           % Fitness function

%% Algorithm parameters
Np = 100                % population size
T = 200                 % number of iterations
limit = 5               % permissible number of failures

%% starting of ABC
f =NaN(Np,1)           % vector to store the objective function value of the population
fit =NaN(Np,1)         % vector to store the fitness function of the population
trial = NaN(Np,1)      % initialising the number of decision variables in the population

D = length(lb)         % Determining the number of decision variables in the population

randpop = repmat(lb,Np,1) + repmat ((ub-lb),Np,1).*rand(Np,D)    %Generation of initial population
trans1 = randpop.'
trans2 = sort(trans1)
P = trans2.'  

for p = 1:Np
    a=P(p,:)
    f(p) = prob(a)    % Evaluating the objective function value
    fit(p) = CalFit(f(p))  % Evaluating the fitness function value
end

[bestobj,ind] = min(f)     % Determine  and memorize the best objective value
bestsol = P(ind,:)         % Determine and memorize the best solution

for t = 1:T
    
 %% Employed Bee phase
 for i= 1:Np
     [trial,P,fit,f] = GenNewSol(prob,lb , ub, Np, i,P ,fit,trial, f, D)
 end
 
 %% Onlooker Bee Phase
 probability = 0.9 * (fit/max(fit)) + 0.1
 
 m = 0; n = 1
 
 while(m < Np)
     if(rand < probability(n))
         [trial,P,fit,f] = GenNewSol (prob, lb, ub, Np, n, P, fit, trial, f,D)
          m = m + 1
     end
     n = mod(n,Np) + 1
 end
 
 [bestobj,ind] = min([f;bestobj])
 CombinedSol = [P;bestsol]
 bestsol = CombinedSol(ind,:)
 
 %% Scout Bee Phase
 [val,ind] = max(trial)
 
 if (val > limit)
     trial(ind) = 0
     P(ind,:) = lb  + (ub-lb).*rand(1,D)
     a= P(ind,:)
     f(ind) = prob (a)
     fit (ind) = CalFit(f(ind))
 end
end

[bestobj,ind] = min([f;bestobj])
CombinedSol = [P;bestsol]
bestsol = CombinedSol(ind,:)
bestsol = sort(bestsol);
a1 = (bestsol(1))
a2 = (bestsol(2))
a3 = (bestsol(3))
Vdc = 85.15
MI = (cosd(a1)+cosd(a2)+cosd(a3))/3
toc
     
