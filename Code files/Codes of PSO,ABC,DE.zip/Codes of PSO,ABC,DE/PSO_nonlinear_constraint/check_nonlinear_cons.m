clc          % clears the command window
clear all    % clears the previous work space
close all    % closes the privous graphical objects(figures)

m=2.19;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  constrained function with equality and inequality contraints
fun=@(x)(9-((2/pi)*(x(1)+(3*x(2))+(5*x(3))))-(1/m^2));
%% constraints for switching angles
constraints=@(x)[x(1)-abs((asin(1/m)));
                 -abs(asin(2/m))+x(2);
                 abs(asin(2/m))-x(3);];

%% Fundamental,3rd elimination
constraints_eq=@(x)[((cos(x(1))+cos(x(2))+cos(x(3)))*(4/pi))-(m);(cos(3*x(1))+cos(3*x(2))+cos(3*x(3)));];

%% Specifications of the algorithm
nvars=3;                % number of variables to be optimized
LB=[0 0 0];             % Lower Bound
UB=[pi/2 pi/2 pi/2];    % Upper Bound
Npop=200;               % Number of population size
max_iter=500;           % Iterations
[Xmin,Fmin]=PSO_non_linear_constraint(fun,constraints,constraints_eq,LB,UB,nvars,Npop,max_iter);
a1=((Xmin(1)))*(180/pi) % converting radians to degree
a2=((Xmin(2)))*(180/pi)
a3=((Xmin(3)))*(180/pi)
Vdc=85.15
m = (4/pi)*(cosd(a1)+cosd(a2)+cosd(a3))

